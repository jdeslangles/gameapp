# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
GameApp::Application.config.secret_token = 'c01a9e1eec3c1427e0aa24dbc4a3e04d7f503dfb979289a6086b90433ed96c9f88fe8950eca9cfe94d6eeba05e9032f91bc45cd165cf966ceb1f1500fb84548b'
