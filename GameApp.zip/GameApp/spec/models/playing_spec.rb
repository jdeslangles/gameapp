require 'spec_helper'

describe Playing do
  pending "add some examples to (or delete) #{__FILE__}"
end
